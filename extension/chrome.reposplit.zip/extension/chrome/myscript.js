//console.log('hello lmao')
var body = document.querySelector('body')
var div = document.createElement('div')
div.setAttribute('id','main')
body.innerHTML = ''
body.appendChild(div)
